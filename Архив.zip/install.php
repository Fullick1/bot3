<?php
include('_set.php');

$add           = R::dispense('settings');
$add->bot_token     = botToken();
$add->admin_chat = chatLogs();
$add->worker_chat     = chatGroup();
R::store($add);
die('ok');